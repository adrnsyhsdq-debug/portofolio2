import { SmoothScroll } from "@/components/smooth-scroll"
import { HeroSection } from "@/components/sections/hero"
import { StatsSection } from "@/components/sections/stats"
import { ServicesSection } from "@/components/sections/services"
import { WorkSection } from "@/components/sections/work"
import { ContactSection } from "@/components/sections/contact"

export default function Home() {
  return (
    <SmoothScroll>
      <main>
        <HeroSection />
        <StatsSection />
        <ServicesSection />
        <WorkSection />
        <ContactSection />
      </main>
    </SmoothScroll>
  )
}

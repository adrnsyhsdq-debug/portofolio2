"use client"

import { useRef } from "react"
import Image from "next/image"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useGSAP } from "@gsap/react"
import { ArrowRight } from "lucide-react"

gsap.registerPlugin(ScrollTrigger, useGSAP)

const projects = [
  {
    title: "Noctara Rebrand",
    tags: ["Web Design", "Framer"],
    image: "/images/project-noctara.png",
    alt: "Noctara luxury brand landing page design",
  },
  {
    title: "SaaS Dashboard",
    tags: ["Next.js", "TypeScript"],
    image: "/images/project-saas.png",
    alt: "SaaS analytics dashboard interface",
  },
  {
    title: "Creative Portfolio",
    tags: ["React", "GSAP"],
    image: "/images/project-creative.png",
    alt: "Experimental creative portfolio website",
  },
]

export function WorkSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      const track = sectionRef.current?.querySelector<HTMLElement>("[data-work-track]")
      const cards = gsap.utils.toArray<HTMLElement>("[data-work-card]")
      if (!track) return

      // Vertical scroll drives horizontal movement of the track
      const scrollTween = gsap.to(track, {
        x: () => -(track.scrollWidth - window.innerWidth),
        ease: "none",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: () => `+=${track.scrollWidth - window.innerWidth}`,
          pin: true,
          scrub: 1,
          invalidateOnRefresh: true,
        },
      })

      // Each card animates as it enters the horizontal viewport
      cards.forEach((card) => {
        gsap.fromTo(
          card,
          { scale: 0.8, opacity: 0, rotateY: -15 },
          {
            scale: 1,
            opacity: 1,
            rotateY: 0,
            ease: "power2.out",
            scrollTrigger: {
              trigger: card,
              containerAnimation: scrollTween,
              start: "left 90%",
              end: "left 40%",
              scrub: true,
            },
          },
        )
      })
    },
    { scope: sectionRef },
  )

  return (
    <section
      ref={sectionRef}
      aria-label="Selected work"
      className="noise relative h-screen w-full overflow-hidden bg-[#0a0a0a]"
    >
      <div className="absolute left-6 top-10 z-10 md:left-12 md:top-14">
        <p className="mb-2 text-xs font-medium uppercase tracking-[0.3em] text-white/40">Selected Work</p>
        <h2 className="font-heading text-3xl font-bold text-white md:text-5xl">Projects</h2>
      </div>

      <div data-work-track className="perspective-deep flex h-full w-max items-center gap-8 px-6 pt-16 md:gap-16 md:px-24">
        {projects.map((project) => (
          <article
            key={project.title}
            data-work-card
            className="glass-dark preserve-3d group w-[80vw] shrink-0 overflow-hidden rounded-3xl sm:w-[60vw] md:w-[42vw]"
          >
            <div className="relative aspect-[16/10] w-full overflow-hidden">
              <Image
                src={project.image || "/placeholder.svg"}
                alt={project.alt}
                fill
                sizes="(max-width: 768px) 80vw, 42vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="flex flex-col gap-4 p-6 md:p-8">
              <div className="flex items-center justify-between gap-4">
                <h3 className="font-heading text-xl font-bold text-white md:text-2xl">{project.title}</h3>
                <ul className="flex flex-wrap justify-end gap-2">
                  {project.tags.map((tag) => (
                    <li
                      key={tag}
                      className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70"
                    >
                      {tag}
                    </li>
                  ))}
                </ul>
              </div>
              <a
                href="#"
                className="inline-flex items-center gap-2 text-sm font-medium text-[#c9a96e] transition-colors hover:text-white"
              >
                View Case Study
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

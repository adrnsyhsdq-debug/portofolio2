"use client"

import { useRef, useState, type FormEvent } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useGSAP } from "@gsap/react"
import { motion } from "framer-motion"
import { Github, Linkedin, Twitter } from "lucide-react"

gsap.registerPlugin(ScrollTrigger, useGSAP)

// Deterministic pseudo-random so SSR and client markup match
function seeded(i: number, salt: number) {
  const x = Math.sin(i * 127.1 + salt * 311.7) * 43758.5453
  return x - Math.floor(x)
}

const socials = [
  { label: "GitHub", href: "#", icon: Github },
  { label: "LinkedIn", href: "#", icon: Linkedin },
  { label: "Twitter", href: "#", icon: Twitter },
]

export function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const [submitted, setSubmitted] = useState(false)

  useGSAP(
    () => {
      const world = sectionRef.current?.querySelector("[data-contact-world]")

      // Camera zooms out of the world as the journey ends
      gsap
        .timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top top",
            end: "+=100%",
            pin: true,
            scrub: 1,
          },
        })
        .fromTo(
          world!,
          { scale: 0.85, opacity: 0.4, filter: "blur(10px)" },
          { scale: 1, opacity: 1, filter: "blur(0px)", ease: "power2.out", duration: 0.5 },
        )
        .to(world!, { scale: 0.6, opacity: 0.3, filter: "blur(10px)", ease: "power2.in", duration: 0.5 }, "+=0.3")
    },
    { scope: sectionRef },
  )

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section
      ref={sectionRef}
      aria-label="Contact"
      className="noise relative h-screen w-full overflow-hidden bg-[#0a0a0a]"
    >
      {/* CSS-only starfield */}
      <div aria-hidden="true" className="absolute inset-0">
        {Array.from({ length: 50 }).map((_, i) => (
          <span
            key={i}
            className="star"
            style={{
              left: `${seeded(i, 1) * 100}%`,
              top: `${seeded(i, 2) * 100}%`,
              width: `${1 + seeded(i, 3) * 2}px`,
              height: `${1 + seeded(i, 3) * 2}px`,
              // @ts-expect-error CSS custom properties
              "--twinkle-duration": `${2 + seeded(i, 4) * 4}s`,
              "--twinkle-delay": `${seeded(i, 5) * 4}s`,
            }}
          />
        ))}
      </div>

      <div data-contact-world className="relative z-10 flex h-full w-full flex-col items-center justify-center gap-8 px-6">
        <h2 className="font-heading text-balance text-center text-4xl font-bold text-white md:text-6xl">
          Let&apos;s build something together
        </h2>

        {submitted ? (
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-dark rounded-2xl px-8 py-6 text-center text-white/80"
          >
            Thanks for reaching out. I&apos;ll get back to you soon.
          </motion.p>
        ) : (
          <form onSubmit={handleSubmit} className="flex w-full max-w-md flex-col gap-4">
            <label className="sr-only" htmlFor="contact-name">
              Name
            </label>
            <input
              id="contact-name"
              name="name"
              type="text"
              required
              placeholder="Name"
              className="glass-dark input-glow rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-white/40"
            />
            <label className="sr-only" htmlFor="contact-email">
              Email
            </label>
            <input
              id="contact-email"
              name="email"
              type="email"
              required
              placeholder="Email"
              className="glass-dark input-glow rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-white/40"
            />
            <label className="sr-only" htmlFor="contact-message">
              Message
            </label>
            <textarea
              id="contact-message"
              name="message"
              required
              rows={4}
              placeholder="Message"
              className="glass-dark input-glow resize-none rounded-xl px-5 py-3.5 text-sm text-white placeholder:text-white/40"
            />
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="rounded-xl bg-[#c9a96e] px-6 py-3.5 text-sm font-semibold text-[#0a0a0a] transition-colors hover:bg-[#d8bc85]"
            >
              Send Message
            </motion.button>
          </form>
        )}

        <nav aria-label="Social links" className="flex items-center gap-6">
          {socials.map((social) => (
            <motion.a
              key={social.label}
              href={social.href}
              whileHover={{ scale: 1.15, y: -2 }}
              className="text-white/50 transition-colors hover:text-[#c9a96e]"
            >
              <social.icon className="h-5 w-5" aria-hidden="true" />
              <span className="sr-only">{social.label}</span>
            </motion.a>
          ))}
        </nav>

        <footer className="absolute bottom-8 text-xs text-white/30">© 2026 Sidik Adriansyah</footer>
      </div>
    </section>
  )
}

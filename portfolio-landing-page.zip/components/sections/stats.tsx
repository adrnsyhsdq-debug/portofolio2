"use client"

import { useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useGSAP } from "@gsap/react"

gsap.registerPlugin(ScrollTrigger, useGSAP)

const stats = [
  { value: "3+", label: "Years Learning", counter: true },
  { value: "Design + Code", label: "Dual Skillset", counter: false },
  { value: "24/7", label: "Remote Ready", counter: false },
]

export function StatsSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      const world = sectionRef.current?.querySelector("[data-stats-world]")
      const cards = gsap.utils.toArray<HTMLElement>("[data-stats-card]")
      const counterEl = sectionRef.current?.querySelector("[data-counter]")

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "+=100%",
          pin: true,
          scrub: 1,
        },
      })

      // Camera pushes forward into this section
      tl.fromTo(
        world!,
        { z: -1000, rotateX: 20, opacity: 0 },
        { z: 0, rotateX: 0, opacity: 1, ease: "power2.out", duration: 1 },
      )

      // Cards fade + scale in
      tl.fromTo(
        cards,
        { scale: 0.8, opacity: 0, y: 60 },
        { scale: 1, opacity: 1, y: 0, stagger: 0.15, ease: "back.out(1.4)", duration: 0.6 },
        "-=0.3",
      )

      // Counter 0 -> 3
      if (counterEl) {
        const counter = { val: 0 }
        tl.to(
          counter,
          {
            val: 3,
            duration: 0.6,
            ease: "power1.out",
            onUpdate: () => {
              counterEl.textContent = `${Math.round(counter.val)}+`
            },
          },
          "-=0.5",
        )
      }
    },
    { scope: sectionRef },
  )

  return (
    <section
      ref={sectionRef}
      aria-label="Capabilities"
      className="relative h-screen w-full overflow-hidden bg-gradient-to-br from-[#E8F4F8] to-[#F0E6FF]"
    >
      <div className="perspective-deep flex h-full w-full items-center justify-center">
        <div data-stats-world className="preserve-3d flex w-full max-w-6xl flex-col items-center gap-12 px-6">
          <div className="text-center">
            <p className="mb-3 text-xs font-medium uppercase tracking-[0.3em] text-neutral-500">Capabilities</p>
            <h2 className="font-heading text-balance text-4xl font-bold text-neutral-900 md:text-6xl">
              One person, two disciplines
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-pretty leading-relaxed text-neutral-600">
              I bridge the gap between aesthetics and functionality. You get consistent vision, faster delivery, and
              lower cost than hiring two separate people.
            </p>
          </div>

          <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-3">
            {stats.map((stat) => (
              <div
                key={stat.label}
                data-stats-card
                className="glass flex flex-col items-center gap-2 rounded-3xl px-8 py-10 text-center shadow-lg shadow-black/5"
              >
                <span
                  data-counter={stat.counter ? "" : undefined}
                  className="font-heading text-4xl font-bold text-neutral-900 md:text-5xl"
                >
                  {stat.value}
                </span>
                <span className="text-sm font-medium uppercase tracking-widest text-neutral-500">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

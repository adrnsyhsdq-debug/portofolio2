"use client"

import { useRef } from "react"
import Image from "next/image"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useGSAP } from "@gsap/react"

gsap.registerPlugin(ScrollTrigger, useGSAP)

const NAME = "Sidik Adriansyah"

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      const world = sectionRef.current?.querySelector("[data-hero-world]")
      const chars = gsap.utils.toArray<HTMLElement>("[data-hero-char]")
      const fadeItems = gsap.utils.toArray<HTMLElement>("[data-hero-fade]")

      // Intro: camera flies in from "outside" the world on page load
      const intro = gsap.timeline({ defaults: { ease: "power2.out" } })

      intro.fromTo(
        world!,
        { scale: 0.3, filter: "blur(20px)", opacity: 0, rotateX: 15 },
        { scale: 1, filter: "blur(0px)", opacity: 1, rotateX: 0, duration: 1.4 },
      )

      // Character-level stagger reveal for the H1
      intro.fromTo(
        chars,
        { yPercent: 100, opacity: 0 },
        { yPercent: 0, opacity: 1, stagger: 0.05, ease: "power3.out", duration: 0.7 },
        "-=0.7",
      )

      // Subtitle + badge + scroll hint
      intro.fromTo(
        fadeItems,
        { y: 100, opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.1, duration: 0.6 },
        "-=0.4",
      )

      // Scroll-scrubbed exit: camera flies past the hero into the next world
      gsap
        .timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top top",
            end: "+=100%",
            pin: true,
            scrub: 1,
          },
        })
        .to(world!, {
          scale: 1.35,
          rotateX: -10,
          filter: "blur(16px)",
          opacity: 0,
          ease: "power2.in",
        })
    },
    { scope: sectionRef },
  )

  return (
    <section
      ref={sectionRef}
      aria-label="Introduction"
      className="noise relative h-screen w-full overflow-hidden bg-[#0a0a0a]"
    >
      <div className="perspective-deep flex h-full w-full items-center justify-center">
        <div data-hero-world className="preserve-3d relative flex h-full w-full items-center justify-center">
          {/* Fullscreen B&W workspace backdrop */}
          <Image
            src="/images/hero-backdrop.png"
            alt=""
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-40 grayscale"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/60 via-transparent to-[#0a0a0a]" />

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center gap-6 px-6 text-center">
            <div
              data-hero-fade
              className="glass-dark rounded-full px-4 py-1.5 text-xs tracking-wide text-white/80 md:text-sm"
            >
              <span className="mr-2 inline-block h-2 w-2 rounded-full bg-emerald-400" aria-hidden="true" />
              Available for freelance work
            </div>

            <h1
              className="font-heading text-balance text-[11vw] font-extrabold uppercase leading-none tracking-tight text-white md:text-[6vw]"
              aria-label={NAME}
            >
              {NAME.split("").map((char, i) => (
                <span key={i} className="inline-block overflow-hidden align-bottom" aria-hidden="true">
                  <span data-hero-char className="inline-block">
                    {char === " " ? "\u00A0" : char}
                  </span>
                </span>
              ))}
            </h1>

            <p data-hero-fade className="text-pretty text-base text-white/70 md:text-[1.5vw]">
              Design Engineer &amp; Frontend Developer
            </p>

            <p data-hero-fade className="max-w-xl text-pretty text-sm leading-relaxed text-white/50 md:text-base">
              I design interfaces in Figma and build them into live, fast, responsive websites with Next.js.
            </p>

            <p data-hero-fade className="mt-8 text-xs uppercase tracking-[0.3em] text-white/40">
              Scroll to explore
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

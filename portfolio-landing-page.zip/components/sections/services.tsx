"use client"

import { useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useGSAP } from "@gsap/react"
import { Palette, Code, Sparkles, Rocket } from "lucide-react"

gsap.registerPlugin(ScrollTrigger, useGSAP)

const services = [
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "Wireframing, high-fidelity prototyping, design systems, responsive layouts in Figma.",
    tags: ["Figma", "Prototyping", "Auto Layout"],
  },
  {
    icon: Code,
    title: "Frontend Development",
    description: "Modern React applications with SSR and optimal performance.",
    tags: ["Next.js", "React", "TypeScript"],
  },
  {
    icon: Sparkles,
    title: "Creative Coding",
    description: "Advanced CSS animations, Canvas graphics, WebGL effects, interactive experiences.",
    tags: ["Animations", "Canvas", "WebGL"],
  },
  {
    icon: Rocket,
    title: "Deployment",
    description: "Zero-config hosting with automatic deployments.",
    tags: ["Vercel", "Git", "GitHub"],
  },
]

export function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useGSAP(
    () => {
      const cards = gsap.utils.toArray<HTMLElement>("[data-service-card]")
      const heading = sectionRef.current?.querySelector("[data-services-heading]")

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "+=100%",
          pin: true,
          scrub: 1,
        },
      })

      tl.fromTo(heading!, { opacity: 0, y: 60 }, { opacity: 1, y: 0, ease: "power2.out", duration: 0.4 })

      // Cards fly through from "inside" the screen into the grid
      tl.fromTo(
        cards,
        {
          scale: 0,
          rotateY: 180,
          z: -500,
          opacity: 0,
          x: (i) => (i % 2 === 0 ? 120 : -120),
          y: (i) => (i < 2 ? 120 : -120),
        },
        {
          scale: 1,
          rotateY: 0,
          z: 0,
          opacity: 1,
          x: 0,
          y: 0,
          stagger: 0.12,
          ease: "power3.out",
          duration: 1,
        },
        "-=0.1",
      )
    },
    { scope: sectionRef },
  )

  return (
    <section
      ref={sectionRef}
      aria-label="Services"
      className="noise relative h-screen w-full overflow-hidden bg-[#0a0a0a]"
    >
      <div className="perspective-deep flex h-full w-full flex-col items-center justify-center gap-8 px-6 md:gap-12">
        <div data-services-heading className="text-center">
          <p className="mb-3 text-xs font-medium uppercase tracking-[0.3em] text-white/40">Services</p>
          <h2 className="font-heading text-balance text-4xl font-bold text-white md:text-6xl">What I do</h2>
        </div>

        <div className="preserve-3d grid w-full max-w-4xl grid-cols-2 gap-3 md:gap-6">
          {services.map((service) => (
            <div
              key={service.title}
              data-service-card
              className="glass-dark group rounded-2xl p-4 transition-transform duration-300 hover:scale-105 md:p-8"
            >
              <service.icon className="mb-2 h-5 w-5 text-[#c9a96e] md:mb-4 md:h-6 md:w-6" aria-hidden="true" />
              <h3 className="chromatic font-heading mb-1 text-sm font-bold text-white md:mb-2 md:text-2xl">
                {service.title}
              </h3>
              <p className="mb-3 hidden text-sm leading-relaxed text-white/60 sm:block md:mb-4">
                {service.description}
              </p>
              <ul className="flex flex-wrap gap-1.5 md:gap-2">
                {service.tags.map((tag) => (
                  <li
                    key={tag}
                    className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-white/70 md:px-3 md:py-1 md:text-xs"
                  >
                    {tag}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
